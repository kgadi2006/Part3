// script.js – main site logic

document.addEventListener("DOMContentLoaded", () => {
  console.log("Amber & Oak Café loaded");

  // Smooth scroll for "Explore Menu" button on home page
  const exploreBtn = document.querySelector("#exploreMenuBtn");
  if (exploreBtn) {
    exploreBtn.addEventListener("click", (e) => {
      e.preventDefault();
      const menuSection = document.querySelector("#menu");
      if (menuSection) menuSection.scrollIntoView({ behavior: "smooth" });
      menuSection.style.display = "block"; // show menu when clicked
    });
  }

  // Search functionality for menu
  const searchInput = document.getElementById("searchInput");
  const menuItems = document.querySelectorAll("#menu .menu-item");

  searchInput.addEventListener("input", () => {
    const filter = searchInput.value.toLowerCase();
    menuItems.forEach(item => {
      const name = item.querySelector("h3").textContent.toLowerCase();
      if (name.includes(filter)) {
        item.style.display = "block";
      } else {
        item.style.display = "none";
      }
    });
  });
});
